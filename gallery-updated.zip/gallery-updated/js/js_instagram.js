  // Function to make the API call
    function ClickBoard() {
            var selectedItemsContent = $("#selected-item-list").html();
            var tempInput = $("<input>");
            $("body").append(tempInput);
            tempInput.val(selectedItemsContent).select();
            document.execCommand("copy");
            tempInput.remove();
            alert("Content copied to clipboard!");
    }

    function callApi(inputValue) {
        // Replace 'your-api-endpoint' with the actual API endpoint URL
        
        const apiUrl = 'https://suite.social/search/search-result.php?q='+inputValue+'&site=Instagram-Leads&rss&apikey=DfbocUOh1x76d9Lt1hfLf5ia1Ugs6Zqu';

        // Use fetch or other AJAX methods to call the API
        $('.loading-icon').show()
        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text(); // Use response.text() to handle XML data
            })
            .then(xmlData => {
                // Parse the XML data
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(xmlData, 'text/xml');

                // Now you can work with the xmlDoc, which contains the parsed XML data
                console.log(xmlDoc);
                $('.loading-icon').hide()
                const imageElements = xmlDoc.getElementsByTagName('image');
                const imageUrls = [];
                for (let i = 0; i < imageElements.length; i++) {
                    const urlElement = imageElements[i].getElementsByTagName('url')[0];
                    if (urlElement) {
                        const imageUrl = urlElement.textContent;
                        imageUrls.push(imageUrl);
                    }
                }

                console.log('Image URLs:', imageUrls);
                const imageGalleryDiv = document.getElementById('selectable');
                imageUrls.forEach(imageUrl => {
                    const imgElement = document.createElement('img');
                    imgElement.src = imageUrl;
                    imgElement.alt = 'Image';
                    imageGalleryDiv.appendChild(imgElement);
                });
                
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    // Add event listener to the input element
    function handleButtonClick() {
            // Get the input value
            const inputValue = document.getElementById('inputValue').value;

            // Call the API with the input value
            callApi(inputValue);
        }

        // Add event listener for the button click
        const callApiButton = document.getElementById('callApiButton');
        callApiButton.addEventListener('click', handleButtonClick);